"use client"

import { useEffect, useRef } from "react"

interface MermaidDiagramProps {
  chart: string
  id: string
}

export function MermaidDiagram({ chart, id }: MermaidDiagramProps) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const renderDiagram = async () => {
      if (typeof window !== "undefined") {
        const mermaid = (await import("mermaid")).default

        mermaid.initialize({
          startOnLoad: true,
          theme: "default",
          securityLevel: "loose",
          fontFamily: "monospace",
        })

        if (ref.current) {
          ref.current.innerHTML = ""
          const { svg } = await mermaid.render(`mermaid-${id}`, chart)
          ref.current.innerHTML = svg
        }
      }
    }

    renderDiagram()
  }, [chart, id])

  return <div ref={ref} className="flex justify-center items-center min-h-[200px] bg-white rounded-lg border p-4" />
}
