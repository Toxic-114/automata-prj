"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Eye, EyeOff } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { MermaidDiagram } from "@/components/mermaid-diagram"

const sections = [
  {
    id: "nfa-dfa",
    title: "NFA to DFA Conversion",
    description: "Convert Non-deterministic Finite Automata to Deterministic Finite Automata",
    icon: "🔄",
  },
  {
    id: "enfa-dfa",
    title: "ε-NFA to DFA Conversion",
    description: "Convert Epsilon Non-deterministic Finite Automata to Deterministic Finite Automata",
    icon: "⚡",
  },
  {
    id: "enfa-nfa",
    title: "ε-NFA to NFA Conversion",
    description: "Convert Epsilon Non-deterministic Finite Automata to Non-deterministic Finite Automata",
    icon: "🔀",
  },
  {
    id: "cfg-pda",
    title: "CFG to PDA Conversion",
    description: "Convert Context-Free Grammar to Pushdown Automata",
    icon: "📚",
  },
]

export default function AutomataProject() {
  const [activeSection, setActiveSection] = useState("nfa-dfa")
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [showSolution, setShowSolution] = useState(false)

  const nextQuestion = () => {
    setCurrentQuestion((prev) => (prev + 1) % 5)
    setShowSolution(false)
  }

  const prevQuestion = () => {
    setCurrentQuestion((prev) => (prev - 1 + 5) % 5)
    setShowSolution(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Theory of Automata Transformations</h1>
          <p className="text-lg text-gray-600 mb-4">Comprehensive Project with Interactive Diagrams</p>
          <div className="flex justify-center gap-2 flex-wrap">
            <Badge variant="secondary">20 Questions</Badge>
            <Badge variant="secondary">4 Categories</Badge>
            <Badge variant="secondary">Interactive Diagrams</Badge>
            <Badge variant="secondary">Step-by-Step Solutions</Badge>
          </div>
        </header>

        <Tabs value={activeSection} onValueChange={setActiveSection} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            {sections.map((section) => (
              <TabsTrigger key={section.id} value={section.id} className="text-xs">
                <span className="mr-1">{section.icon}</span>
                {section.title.split(" ")[0]}
              </TabsTrigger>
            ))}
          </TabsList>

          {sections.map((section) => (
            <TabsContent key={section.id} value={section.id}>
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-2xl">{section.icon}</span>
                    {section.title}
                  </CardTitle>
                  <CardDescription>{section.description}</CardDescription>
                </CardHeader>
              </Card>

              <div className="flex justify-between items-center mb-4">
                <Button onClick={prevQuestion} variant="outline" size="sm">
                  <ChevronLeft className="w-4 h-4 mr-1" />
                  Previous
                </Button>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-gray-600">Question {currentQuestion + 1} of 5</span>
                  <Button
                    onClick={() => setShowSolution(!showSolution)}
                    variant={showSolution ? "default" : "outline"}
                    size="sm"
                  >
                    {showSolution ? <EyeOff className="w-4 h-4 mr-1" /> : <Eye className="w-4 h-4 mr-1" />}
                    {showSolution ? "Hide" : "Show"} Solution
                  </Button>
                </div>
                <Button onClick={nextQuestion} variant="outline" size="sm">
                  Next
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>

              {section.id === "nfa-dfa" && (
                <NFAToDFAQuestions questionIndex={currentQuestion} showSolution={showSolution} />
              )}
              {section.id === "enfa-dfa" && (
                <ENFAToDFAQuestions questionIndex={currentQuestion} showSolution={showSolution} />
              )}
              {section.id === "enfa-nfa" && (
                <ENFAToNFAQuestions questionIndex={currentQuestion} showSolution={showSolution} />
              )}
              {section.id === "cfg-pda" && (
                <CFGToPDAQuestions questionIndex={currentQuestion} showSolution={showSolution} />
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  )
}

function NFAToDFAQuestions({ questionIndex, showSolution }: { questionIndex: number; showSolution: boolean }) {
  const questions = [
    {
      difficulty: "Easy",
      title: "Basic NFA to DFA Conversion",
      problem: "Convert the following NFA to DFA using subset construction:",
      nfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q0 : a,b
          q0 --> q1 : a
          q1 --> q2 : b
          q2 --> [*]
          
          note right of q2 : Accept State
      `,
      dfaDiagram: `
        stateDiagram-v2
          [*] --> S0
          S0 --> S1 : a
          S0 --> S0 : b
          S1 --> S1 : a
          S1 --> S2 : b
          S2 --> S1 : a
          S2 --> S0 : b
          S2 --> [*]
          
          note right of S0 : {q0}
          note right of S1 : {q0,q1}
          note right of S2 : {q0,q2}
      `,
      conversionSteps: `
        graph TD
          A["Start: {q0}"] --> B["On 'a': {q0,q1}"]
          A --> C["On 'b': {q0}"]
          B --> D["On 'a': {q0,q1}"]
          B --> E["On 'b': {q0,q2}"]
          E --> F["On 'a': {q0,q1}"]
          E --> G["On 'b': {q0}"]
          
          style A fill:#e1f5fe
          style E fill:#c8e6c9
      `,
      nfa: {
        states: ["q0", "q1", "q2"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: ["q0", "q1"], b: ["q0"] },
          q1: { a: [], b: ["q2"] },
          q2: { a: [], b: [] },
        },
        startState: "q0",
        acceptStates: ["q2"],
      },
    },
    {
      difficulty: "Easy-Medium",
      title: "NFA with Multiple Transitions",
      problem: "Convert NFA with multiple transitions on same symbol:",
      nfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : a
          q0 --> q2 : a
          q0 --> q0 : b
          q1 --> q3 : a
          q2 --> q3 : b
          q3 --> [*]
          
          note right of q3 : Accept State
      `,
      dfaDiagram: `
        stateDiagram-v2
          [*] --> S0
          S0 --> S1 : a
          S0 --> S0 : b
          S1 --> S2 : a
          S1 --> S2 : b
          S2 --> S3 : a,b
          S3 --> S3 : a,b
          S2 --> [*]
          
          note right of S0 : {q0}
          note right of S1 : {q1,q2}
          note right of S2 : {q3}
          note right of S3 : ∅
      `,
      conversionSteps: `
        graph TD
          A["Start: {q0}"] --> B["On 'a': {q1,q2}"]
          A --> C["On 'b': {q0}"]
          B --> D["On 'a': {q3}"]
          B --> E["On 'b': {q3}"]
          D --> F["On 'a,b': ∅"]
          F --> F
          
          style A fill:#e1f5fe
          style D fill:#c8e6c9
          style E fill:#c8e6c9
      `,
      nfa: {
        states: ["q0", "q1", "q2", "q3"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: ["q1", "q2"], b: ["q0"] },
          q1: { a: ["q3"], b: [] },
          q2: { a: [], b: ["q3"] },
          q3: { a: [], b: [] },
        },
        startState: "q0",
        acceptStates: ["q3"],
      },
    },
    {
      difficulty: "Medium",
      title: "NFA with Dead States",
      problem: "Convert NFA containing unreachable and dead states:",
      nfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : a
          q0 --> q2 : b
          q1 --> q3 : a
          q1 --> q1 : b
          q2 --> q2 : a
          q2 --> q3 : b
          q3 --> [*]
          q4 --> q4 : a,b
          
          note right of q3 : Accept State
          note right of q4 : Unreachable
      `,
      dfaDiagram: `
        stateDiagram-v2
          [*] --> S0
          S0 --> S1 : a
          S0 --> S2 : b
          S1 --> S3 : a
          S1 --> S1 : b
          S2 --> S2 : a
          S2 --> S3 : b
          S3 --> S4 : a,b
          S4 --> S4 : a,b
          S3 --> [*]
          
          note right of S0 : {q0}
          note right of S1 : {q1}
          note right of S2 : {q2}
          note right of S3 : {q3}
          note right of S4 : ∅
      `,
      conversionSteps: `
        graph TD
          A["Start: {q0}"] --> B["On 'a': {q1}"]
          A --> C["On 'b': {q2}"]
          B --> D["On 'a': {q3}"]
          B --> E["On 'b': {q1}"]
          C --> F["On 'a': {q2}"]
          C --> G["On 'b': {q3}"]
          D --> H["On 'a,b': ∅"]
          H --> H
          
          style A fill:#e1f5fe
          style D fill:#c8e6c9
          style G fill:#c8e6c9
      `,
      nfa: {
        states: ["q0", "q1", "q2", "q3", "q4"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: ["q1"], b: ["q2"] },
          q1: { a: ["q3"], b: ["q1"] },
          q2: { a: ["q2"], b: ["q3"] },
          q3: { a: [], b: [] },
          q4: { a: ["q4"], b: ["q4"] },
        },
        startState: "q0",
        acceptStates: ["q3"],
      },
    },
    {
      difficulty: "Medium-Hard",
      title: "Complex NFA with Loops",
      problem: "Convert NFA with complex state transitions and loops:",
      nfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : a
          q0 --> q3 : a
          q0 --> q2 : b
          q1 --> q2 : a
          q1 --> q1 : b
          q1 --> q4 : b
          q2 --> q0 : a
          q2 --> q3 : b
          q3 --> q4 : a
          q3 --> q0 : b
          q4 --> [*]
          
          note right of q4 : Accept State
      `,
      dfaDiagram: `
        stateDiagram-v2
          [*] --> S0
          S0 --> S1 : a
          S0 --> S2 : b
          S1 --> S3 : a
          S1 --> S4 : b
          S2 --> S1 : a
          S2 --> S5 : b
          S3 --> S1 : a
          S3 --> S5 : b
          S4 --> S3 : a
          S4 --> S6 : b
          S5 --> S7 : a
          S5 --> S0 : b
          S6 --> S3 : a
          S6 --> S6 : b
          S7 --> S3 : a
          S7 --> S4 : b
          S4 --> [*]
          S6 --> [*]
          
          note right of S0 : {q0}
          note right of S1 : {q1,q3}
          note right of S2 : {q2}
          note right of S3 : {q2,q4}
          note right of S4 : {q0,q1,q4}
          note right of S5 : {q0,q3}
          note right of S6 : {q0,q1,q4}
          note right of S7 : {q1,q3,q4}
      `,
      conversionSteps: `
        graph TD
          A["Start: {q0}"] --> B["On 'a': {q1,q3}"]
          A --> C["On 'b': {q2}"]
          B --> D["On 'a': {q2,q4}"]
          B --> E["On 'b': {q0,q1,q4}"]
          C --> F["On 'a': {q0}"]
          C --> G["On 'b': {q3}"]
          
          style A fill:#e1f5fe
          style D fill:#c8e6c9
          style E fill:#c8e6c9
      `,
      nfa: {
        states: ["q0", "q1", "q2", "q3", "q4"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: ["q1", "q3"], b: ["q2"] },
          q1: { a: ["q2"], b: ["q1", "q4"] },
          q2: { a: ["q0"], b: ["q3"] },
          q3: { a: ["q4"], b: ["q0"] },
          q4: { a: [], b: [] },
        },
        startState: "q0",
        acceptStates: ["q4"],
      },
    },
    {
      difficulty: "Hard",
      title: "Advanced NFA with Multiple Accept States",
      problem: "Convert complex NFA with multiple accept states and intricate transitions:",
      nfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : a
          q0 --> q2 : a
          q0 --> q0 : b
          q0 --> q3 : c
          q1 --> q4 : a
          q1 --> q1 : b
          q1 --> q5 : b
          q2 --> q3 : b
          q2 --> q4 : c
          q3 --> q5 : a
          q3 --> q0 : c
          q4 --> q5 : b
          q4 --> [*]
          q5 --> [*]
          
          note right of q4 : Accept State
          note right of q5 : Accept State
      `,
      dfaDiagram: `
        stateDiagram-v2
          [*] --> S0
          S0 --> S1 : a
          S0 --> S0 : b
          S0 --> S2 : c
          S1 --> S3 : a
          S1 --> S4 : b
          S1 --> S5 : c
          S2 --> S6 : a
          S2 --> S7 : b,c
          S3 --> S8 : b
          S3 --> S5 : c
          S4 --> S3 : a
          S4 --> S9 : b
          S4 --> S5 : c
          S5 --> S8 : b
          S5 --> S5 : c
          S6 --> S7 : c
          S8 --> S7 : a,b,c
          S9 --> S3 : a
          S9 --> S9 : b
          S9 --> S5 : c
          
          S3 --> [*]
          S4 --> [*]
          S5 --> [*]
          S6 --> [*]
          S8 --> [*]
          S9 --> [*]
          
          note right of S0 : {q0}
          note right of S1 : {q1,q2}
          note right of S2 : {q3}
          note right of S3 : {q4}
          note right of S4 : {q1,q3,q5}
          note right of S5 : {q4}
          note right of S6 : {q5}
          note right of S8 : {q5}
          note right of S9 : {q1,q5}
      `,
      conversionSteps: `
        graph TD
          A["Start: {q0}"] --> B["On 'a': {q1,q2}"]
          A --> C["On 'b': {q0}"]
          A --> D["On 'c': {q3}"]
          B --> E["On 'a': {q4}"]
          B --> F["On 'b': {q1,q3,q5}"]
          B --> G["On 'c': {q4}"]
          
          style A fill:#e1f5fe
          style E fill:#c8e6c9
          style F fill:#c8e6c9
          style G fill:#c8e6c9
      `,
      nfa: {
        states: ["q0", "q1", "q2", "q3", "q4", "q5"],
        alphabet: ["a", "b", "c"],
        transitions: {
          q0: { a: ["q1", "q2"], b: ["q0"], c: ["q3"] },
          q1: { a: ["q4"], b: ["q1", "q5"], c: [] },
          q2: { a: [], b: ["q3"], c: ["q4"] },
          q3: { a: ["q5"], b: [], c: ["q0"] },
          q4: { a: [], b: ["q5"], c: [] },
          q5: { a: [], b: [], c: [] },
        },
        startState: "q0",
        acceptStates: ["q4", "q5"],
      },
    },
  ]

  const question = questions[questionIndex]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <CardTitle className="text-xl">
              Question {questionIndex + 1}: {question.title}
            </CardTitle>
            <Badge
              variant={
                question.difficulty === "Easy"
                  ? "secondary"
                  : question.difficulty === "Medium"
                    ? "default"
                    : "destructive"
              }
            >
              {question.difficulty}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold mb-2">Problem Statement:</h3>
            <p>{question.problem}</p>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Given NFA:</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p>
                <strong>States (Q):</strong> {`{${question.nfa.states.join(", ")}}`}
              </p>
              <p>
                <strong>Alphabet (Σ):</strong> {`{${question.nfa.alphabet.join(", ")}}`}
              </p>
              <p>
                <strong>Start State (q₀):</strong> {question.nfa.startState}
              </p>
              <p>
                <strong>Accept States (F):</strong> {`{${question.nfa.acceptStates.join(", ")}}`}
              </p>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-2">NFA State Diagram:</h3>
            <MermaidDiagram chart={question.nfaDiagram} id={`nfa-${questionIndex}`} />
          </div>

          <div>
            <h3 className="font-semibold mb-2">Transition Table:</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full border border-gray-300">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border border-gray-300 px-4 py-2">State</th>
                    {question.nfa.alphabet.map((symbol) => (
                      <th key={symbol} className="border border-gray-300 px-4 py-2">
                        {symbol}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {question.nfa.states.map((state) => (
                    <tr key={state}>
                      <td className="border border-gray-300 px-4 py-2 font-mono">
                        {state}
                        {question.nfa.acceptStates.includes(state) ? "*" : ""}
                      </td>
                      {question.nfa.alphabet.map((symbol) => (
                        <td key={symbol} className="border border-gray-300 px-4 py-2 font-mono">
                          {`{${question.nfa.transitions[state][symbol].join(", ") || "∅"}}`}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </CardContent>
      </Card>

      {showSolution && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800">Solution: Subset Construction Algorithm</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-semibold mb-2 text-green-800">Conversion Process:</h3>
              <MermaidDiagram chart={question.conversionSteps} id={`conversion-${questionIndex}`} />
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Resulting DFA:</h3>
              <MermaidDiagram chart={question.dfaDiagram} id={`dfa-${questionIndex}`} />
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Algorithm Steps:</h3>
              <div className="space-y-3">
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 1: Initialize</h4>
                  <p>Start with the singleton set containing the initial state: {`{${question.nfa.startState}}`}</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 2: Subset Construction</h4>
                  <p>For each state set S and input symbol a, compute δ(S,a) = ⋃{`{δ(q,a) | q ∈ S}`}</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 3: Create New States</h4>
                  <p>Each unique subset becomes a DFA state. Continue until no new states are generated.</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 4: Mark Accept States</h4>
                  <p>A DFA state is accepting if it contains at least one NFA accept state.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function ENFAToDFAQuestions({ questionIndex, showSolution }: { questionIndex: number; showSolution: boolean }) {
  const questions = [
    {
      difficulty: "Easy",
      title: "Basic ε-NFA to DFA Conversion",
      problem: "Convert the following ε-NFA to DFA using ε-closure method:",
      enfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : ε
          q1 --> q2 : a
          q2 --> q2 : b
          q2 --> [*]
          
          note right of q2 : Accept State
      `,
      dfaDiagram: `
        stateDiagram-v2
          [*] --> S0
          S0 --> S1 : a
          S1 --> S1 : b
          S1 --> [*]
          
          note right of S0 : {q0,q1}
          note right of S1 : {q2}
      `,
      epsilonClosureDiagram: `
        graph TD
          A["ε-closure(q0)"] --> B["{q0, q1}"]
          C["ε-closure(q1)"] --> D["{q1}"]
          E["ε-closure(q2)"] --> F["{q2}"]
          
          style B fill:#e1f5fe
          style D fill:#fff3e0
          style F fill:#c8e6c9
      `,
      enfa: {
        states: ["q0", "q1", "q2"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: [], b: [], ε: ["q1"] },
          q1: { a: ["q2"], b: [], ε: [] },
          q2: { a: [], b: ["q2"], ε: [] },
        },
        startState: "q0",
        acceptStates: ["q2"],
      },
    },
    {
      difficulty: "Easy-Medium",
      title: "ε-NFA with Multiple ε-transitions",
      problem: "Convert ε-NFA with multiple epsilon transitions:",
      enfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : a
          q0 --> q2 : ε
          q1 --> q3 : b
          q2 --> q3 : ε
          q3 --> q3 : a
          q3 --> [*]
          
          note right of q3 : Accept State
      `,
      dfaDiagram: `
        stateDiagram-v2
          [*] --> S0
          S0 --> S1 : a
          S1 --> S2 : b
          S2 --> S2 : a
          S0 --> [*]
          S2 --> [*]
          
          note right of S0 : {q0,q2,q3}
          note right of S1 : {q1}
          note right of S2 : {q3}
      `,
      epsilonClosureDiagram: `
        graph TD
          A["ε-closure(q0)"] --> B["{q0, q2, q3}"]
          C["ε-closure(q1)"] --> D["{q1}"]
          E["ε-closure(q2)"] --> F["{q2, q3}"]
          G["ε-closure(q3)"] --> H["{q3}"]
          
          style B fill:#e1f5fe
          style D fill:#fff3e0
          style F fill:#f3e5f5
          style H fill:#c8e6c9
      `,
      enfa: {
        states: ["q0", "q1", "q2", "q3"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: ["q1"], b: [], ε: ["q2"] },
          q1: { a: [], b: ["q3"], ε: [] },
          q2: { a: [], b: [], ε: ["q3"] },
          q3: { a: ["q3"], b: [], ε: [] },
        },
        startState: "q0",
        acceptStates: ["q3"],
      },
    },
    {
      difficulty: "Medium",
      title: "ε-NFA with Loops and ε-cycles",
      problem: "Convert ε-NFA containing epsilon cycles:",
      enfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : ε
          q0 --> q2 : ε
          q1 --> q3 : a
          q1 --> q2 : ε
          q2 --> q3 : b
          q2 --> q1 : ε
          q3 --> [*]
          
          note right of q3 : Accept State
      `,
      dfaDiagram: `
        stateDiagram-v2
          [*] --> S0
          S0 --> S1 : a,b
          S1 --> [*]
          
          note right of S0 : {q0,q1,q2}
          note right of S1 : {q3}
      `,
      epsilonClosureDiagram: `
        graph TD
          A["ε-closure(q0)"] --> B["{q0, q1, q2}"]
          C["ε-closure(q1)"] --> D["{q1, q2}"]
          E["ε-closure(q2)"] --> F["{q1, q2}"]
          G["ε-closure(q3)"] --> H["{q3}"]
          
          style B fill:#e1f5fe
          style D fill:#fff3e0
          style F fill:#fff3e0
          style H fill:#c8e6c9
      `,
      enfa: {
        states: ["q0", "q1", "q2", "q3"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: [], b: [], ε: ["q1", "q2"] },
          q1: { a: ["q3"], b: [], ε: ["q2"] },
          q2: { a: [], b: ["q3"], ε: ["q1"] },
          q3: { a: [], b: [], ε: [] },
        },
        startState: "q0",
        acceptStates: ["q3"],
      },
    },
    {
      difficulty: "Medium-Hard",
      title: "Complex ε-NFA with Mixed Transitions",
      problem: "Convert ε-NFA with both regular and epsilon transitions:",
      enfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : a
          q0 --> q2 : ε
          q1 --> q4 : b
          q1 --> q3 : ε
          q2 --> q3 : a
          q2 --> q2 : b
          q3 --> q4 : ε
          q4 --> q4 : a
          q4 --> [*]
          
          note right of q4 : Accept State
      `,
      dfaDiagram: `
        stateDiagram-v2
          [*] --> S0
          S0 --> S1 : a
          S0 --> S2 : b
          S1 --> S3 : b
          S2 --> S4 : a
          S2 --> S2 : b
          S3 --> S3 : a
          S4 --> S3 : b
          S1 --> [*]
          S3 --> [*]
          S4 --> [*]
          
          note right of S0 : {q0,q2}
          note right of S1 : {q1,q3,q4}
          note right of S2 : {q2}
          note right of S3 : {q4}
          note right of S4 : {q3,q4}
      `,
      epsilonClosureDiagram: `
        graph TD
          A["ε-closure(q0)"] --> B["{q0, q2}"]
          C["ε-closure(q1)"] --> D["{q1, q3, q4}"]
          E["ε-closure(q2)"] --> F["{q2}"]
          G["ε-closure(q3)"] --> H["{q3, q4}"]
          I["ε-closure(q4)"] --> J["{q4}"]
          
          style B fill:#e1f5fe
          style D fill:#fff3e0
          style F fill:#f3e5f5
          style H fill:#e8f5e8
          style J fill:#c8e6c9
      `,
      enfa: {
        states: ["q0", "q1", "q2", "q3", "q4"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: ["q1"], b: [], ε: ["q2"] },
          q1: { a: [], b: ["q4"], ε: ["q3"] },
          q2: { a: ["q3"], b: ["q2"], ε: [] },
          q3: { a: [], b: [], ε: ["q4"] },
          q4: { a: ["q4"], b: [], ε: [] },
        },
        startState: "q0",
        acceptStates: ["q4"],
      },
    },
    {
      difficulty: "Hard",
      title: "Advanced ε-NFA with Complex ε-closures",
      problem: "Convert highly complex ε-NFA with intricate epsilon transitions:",
      enfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : ε
          q0 --> q3 : ε
          q1 --> q2 : a
          q1 --> q4 : ε
          q2 --> q5 : b
          q3 --> q4 : b
          q3 --> q5 : c
          q4 --> q5 : ε
          q5 --> q5 : a
          q5 --> q0 : ε
          q2 --> [*]
          q5 --> [*]
          
          note right of q2 : Accept State
          note right of q5 : Accept State
      `,
      dfaDiagram: `
        stateDiagram-v2
          [*] --> S0
          S0 --> S1 : a
          S0 --> S2 : b
          S0 --> S3 : c
          S1 --> S4 : b
          S2 --> S5 : a
          S2 --> S2 : b
          S2 --> S3 : c
          S3 --> S5 : a
          S3 --> S2 : b
          S3 --> S3 : c
          S4 --> S5 : a
          S4 --> S2 : b
          S4 --> S3 : c
          S5 --> S4 : b
          S5 --> S5 : a
          S5 --> S3 : c
          
          S1 --> [*]
          S2 --> [*]
          S3 --> [*]
          S4 --> [*]
          S5 --> [*]
          
          note right of S0 : {q0,q1,q3,q4,q5}
          note right of S1 : {q2}
          note right of S2 : {q0,q1,q3,q4,q5}
          note right of S3 : {q0,q1,q3,q4,q5}
          note right of S4 : {q0,q1,q3,q4,q5}
          note right of S5 : {q0,q1,q3,q4,q5}
      `,
      epsilonClosureDiagram: `
        graph TD
          A["ε-closure(q0)"] --> B["{q0,q1,q3,q4,q5}"]
          C["ε-closure(q1)"] --> D["{q1,q4,q5,q0,q3}"]
          E["ε-closure(q2)"] --> F["{q2}"]
          G["ε-closure(q3)"] --> H["{q3}"]
          I["ε-closure(q4)"] --> J["{q4,q5,q0,q1,q3}"]
          K["ε-closure(q5)"] --> L["{q5,q0,q1,q3,q4}"]
          
          style B fill:#e1f5fe
          style D fill:#fff3e0
          style F fill:#f3e5f5
          style H fill:#e8f5e8
          style J fill:#fce4ec
          style L fill:#c8e6c9
      `,
      enfa: {
        states: ["q0", "q1", "q2", "q3", "q4", "q5"],
        alphabet: ["a", "b", "c"],
        transitions: {
          q0: { a: [], b: [], c: [], ε: ["q1", "q3"] },
          q1: { a: ["q2"], b: [], c: [], ε: ["q4"] },
          q2: { a: [], b: ["q5"], c: [], ε: [] },
          q3: { a: [], b: ["q4"], c: ["q5"], ε: [] },
          q4: { a: [], b: [], c: [], ε: ["q5"] },
          q5: { a: ["q5"], b: [], c: [], ε: ["q0"] },
        },
        startState: "q0",
        acceptStates: ["q2", "q5"],
      },
    },
  ]

  const question = questions[questionIndex]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <CardTitle className="text-xl">
              Question {questionIndex + 1}: {question.title}
            </CardTitle>
            <Badge
              variant={
                question.difficulty === "Easy"
                  ? "secondary"
                  : question.difficulty === "Medium"
                    ? "default"
                    : "destructive"
              }
            >
              {question.difficulty}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold mb-2">Problem Statement:</h3>
            <p>{question.problem}</p>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Given ε-NFA:</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p>
                <strong>States (Q):</strong> {`{${question.enfa.states.join(", ")}}`}
              </p>
              <p>
                <strong>Alphabet (Σ):</strong> {`{${question.enfa.alphabet.join(", ")}}`}
              </p>
              <p>
                <strong>Start State (q₀):</strong> {question.enfa.startState}
              </p>
              <p>
                <strong>Accept States (F):</strong> {`{${question.enfa.acceptStates.join(", ")}}`}
              </p>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-2">ε-NFA State Diagram:</h3>
            <MermaidDiagram chart={question.enfaDiagram} id={`enfa-${questionIndex}`} />
          </div>

          <div>
            <h3 className="font-semibold mb-2">Transition Table:</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full border border-gray-300">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border border-gray-300 px-4 py-2">State</th>
                    {question.enfa.alphabet.map((symbol) => (
                      <th key={symbol} className="border border-gray-300 px-4 py-2">
                        {symbol}
                      </th>
                    ))}
                    <th className="border border-gray-300 px-4 py-2">ε</th>
                  </tr>
                </thead>
                <tbody>
                  {question.enfa.states.map((state) => (
                    <tr key={state}>
                      <td className="border border-gray-300 px-4 py-2 font-mono">
                        {state}
                        {question.enfa.acceptStates.includes(state) ? "*" : ""}
                      </td>
                      {question.enfa.alphabet.map((symbol) => (
                        <td key={symbol} className="border border-gray-300 px-4 py-2 font-mono">
                          {`{${question.enfa.transitions[state][symbol].join(", ") || "∅"}}`}
                        </td>
                      ))}
                      <td className="border border-gray-300 px-4 py-2 font-mono">
                        {`{${question.enfa.transitions[state]["ε"].join(", ") || "∅"}}`}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </CardContent>
      </Card>

      {showSolution && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800">Solution: ε-NFA to DFA Conversion</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-semibold mb-2 text-green-800">ε-Closures:</h3>
              <MermaidDiagram chart={question.epsilonClosureDiagram} id={`epsilon-${questionIndex}`} />
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Resulting DFA:</h3>
              <MermaidDiagram chart={question.dfaDiagram} id={`dfa-enfa-${questionIndex}`} />
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Conversion Algorithm:</h3>
              <div className="space-y-3">
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 1: Compute ε-closures</h4>
                  <p>For each state q, find ε-closure(q) = all states reachable from q using only ε-transitions</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 2: Initial DFA State</h4>
                  <p>Start state of DFA = ε-closure(start state of ε-NFA)</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 3: Construct Transitions</h4>
                  <p>For DFA state S and symbol a: δ'(S,a) = ε-closure(⋃{`{δ(q,a) | q ∈ S}`})</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 4: Mark Accept States</h4>
                  <p>DFA state S is accepting if S ∩ F ≠ ∅</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Mathematical Definition:</h3>
              <div className="bg-white p-4 rounded-lg border border-green-200 font-mono text-sm">
                <p>ε-closure(q) = {`{q} ∪ {p | q →* p using only ε-transitions}`}</p>
                <p className="mt-2">For DFA construction:</p>
                <p>δ'(S, a) = ε-closure(⋃{`{δ(q, a) | q ∈ S}`})</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function ENFAToNFAQuestions({ questionIndex, showSolution }: { questionIndex: number; showSolution: boolean }) {
  const questions = [
    {
      difficulty: "Easy",
      title: "Basic ε-NFA to NFA Conversion",
      problem: "Convert the following ε-NFA to equivalent NFA by eliminating ε-transitions:",
      enfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : ε
          q1 --> q2 : a
          q2 --> q2 : b
          q2 --> [*]
          
          note right of q2 : Accept State
      `,
      nfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q2 : a
          q1 --> q2 : a
          q2 --> q2 : b
          q0 --> [*]
          q2 --> [*]
          
          note right of q0 : Modified (now accepting)
          note right of q2 : Accept State
      `,
      eliminationProcess: `
        graph TD
          A["Original ε-NFA"] --> B["Compute ε-closures"]
          B --> C["ε-closure(q0) = {q0,q1}"]
          C --> D["Add transitions: q0 --a--> q2"]
          D --> E["q0 becomes accepting (reaches q2)"]
          E --> F["Remove ε-transitions"]
          F --> G["Resulting NFA"]
          
          style A fill:#ffebee
          style G fill:#e8f5e8
      `,
      enfa: {
        states: ["q0", "q1", "q2"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: [], b: [], ε: ["q1"] },
          q1: { a: ["q2"], b: [], ε: [] },
          q2: { a: [], b: ["q2"], ε: [] },
        },
        startState: "q0",
        acceptStates: ["q2"],
      },
    },
    {
      difficulty: "Easy-Medium",
      title: "ε-NFA with Multiple ε-paths",
      problem: "Convert ε-NFA with multiple epsilon paths to NFA:",
      enfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : a
          q0 --> q2 : ε
          q1 --> q3 : ε
          q2 --> q3 : b
          q3 --> q3 : a
          q3 --> [*]
          
          note right of q3 : Accept State
      `,
      nfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : a
          q0 --> q3 : b
          q1 --> q3 : a
          q2 --> q3 : b
          q3 --> q3 : a
          q0 --> [*]
          q3 --> [*]
          
          note right of q0 : Now accepting
          note right of q3 : Accept State
      `,
      eliminationProcess: `
        graph TD
          A["ε-closure(q0) = {q0,q2,q3}"] --> B["q0 can reach q3 via ε"]
          B --> C["Add: q0 --b--> q3"]
          C --> D["ε-closure(q1) = {q1,q3}"]
          D --> E["Add: q1 --a--> q3"]
          E --> F["q0 becomes accepting"]
          F --> G["Remove all ε-transitions"]
          
          style A fill:#e1f5fe
          style G fill:#c8e6c9
      `,
      enfa: {
        states: ["q0", "q1", "q2", "q3"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: ["q1"], b: [], ε: ["q2"] },
          q1: { a: [], b: [], ε: ["q3"] },
          q2: { a: [], b: ["q3"], ε: [] },
          q3: { a: ["q3"], b: [], ε: [] },
        },
        startState: "q0",
        acceptStates: ["q3"],
      },
    },
    {
      difficulty: "Medium",
      title: "ε-NFA with ε-cycles",
      problem: "Convert ε-NFA containing epsilon cycles to NFA:",
      enfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : ε
          q1 --> q3 : a
          q1 --> q2 : ε
          q2 --> q3 : b
          q2 --> q1 : ε
          q3 --> [*]
          
          note right of q3 : Accept State
          note left of q1 : ε-cycle
          note left of q2 : ε-cycle
      `,
      nfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q3 : a,b
          q1 --> q3 : a,b
          q2 --> q3 : a,b
          q3 --> q3 : a,b
          q0 --> [*]
          q3 --> [*]
          
          note right of q0 : Now accepting
          note right of q3 : Accept State
      `,
      eliminationProcess: `
        graph TD
          A["Detect ε-cycle: q1 ↔ q2"] --> B["ε-closure(q1) = {q1,q2}"]
          B --> C["ε-closure(q2) = {q1,q2}"]
          C --> D["ε-closure(q0) = {q0,q1,q2}"]
          D --> E["Add transitions from q0: a,b → q3"]
          E --> F["q0 becomes accepting"]
          F --> G["Remove ε-transitions"]
          
          style A fill:#ffebee
          style G fill:#c8e6c9
      `,
      enfa: {
        states: ["q0", "q1", "q2", "q3"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: [], b: [], ε: ["q1"] },
          q1: { a: ["q3"], b: [], ε: ["q2"] },
          q2: { a: [], b: ["q3"], ε: ["q1"] },
          q3: { a: [], b: [], ε: [] },
        },
        startState: "q0",
        acceptStates: ["q3"],
      },
    },
    {
      difficulty: "Medium-Hard",
      title: "Complex ε-NFA with Mixed Transitions",
      problem: "Convert complex ε-NFA with both regular and epsilon transitions:",
      enfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : a
          q0 --> q2 : ε
          q1 --> q4 : b
          q1 --> q3 : ε
          q2 --> q3 : a
          q2 --> q2 : b
          q3 --> q4 : ε
          q4 --> q4 : a
          q4 --> [*]
          
          note right of q4 : Accept State
      `,
      nfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : a
          q0 --> q3 : a
          q0 --> q2 : b
          q1 --> q4 : a,b
          q2 --> q3 : a
          q2 --> q4 : a
          q2 --> q2 : b
          q3 --> q4 : a
          q4 --> q4 : a
          q0 --> [*]
          q1 --> [*]
          q3 --> [*]
          q4 --> [*]
          
          note right of q0 : Now accepting
          note right of q1 : Now accepting
          note right of q3 : Now accepting
          note right of q4 : Accept State
      `,
      eliminationProcess: `
        graph TD
          A["ε-closure(q0) = {q0,q2}"] --> B["ε-closure(q1) = {q1,q3,q4}"]
          B --> C["ε-closure(q3) = {q3,q4}"]
          C --> D["Add new transitions"]
          D --> E["q0: a→{q3}, b→{q2}"]
          E --> F["q1: b→{q4}"]
          F --> G["Update accept states"]
          G --> H["Remove ε-transitions"]
          
          style A fill:#e1f5fe
          style H fill:#c8e6c9
      `,
      enfa: {
        states: ["q0", "q1", "q2", "q3", "q4"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: ["q1"], b: [], ε: ["q2"] },
          q1: { a: [], b: ["q4"], ε: ["q3"] },
          q2: { a: ["q3"], b: ["q2"], ε: [] },
          q3: { a: [], b: [], ε: ["q4"] },
          q4: { a: ["q4"], b: [], ε: [] },
        },
        startState: "q0",
        acceptStates: ["q4"],
      },
    },
    {
      difficulty: "Hard",
      title: "Advanced ε-NFA with Complex Structure",
      problem: "Convert highly complex ε-NFA with intricate epsilon transitions:",
      enfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : ε
          q0 --> q3 : ε
          q1 --> q2 : a
          q1 --> q4 : ε
          q2 --> q5 : b
          q3 --> q4 : b
          q4 --> q5 : ε
          q5 --> q5 : a
          q2 --> [*]
          q5 --> [*]
          
          note right of q2 : Accept State
          note right of q5 : Accept State
      `,
      nfaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q2 : a
          q0 --> q4 : b
          q0 --> q5 : b
          q1 --> q2 : a
          q1 --> q5 : b
          q2 --> q5 : b
          q3 --> q4 : b
          q3 --> q5 : b
          q4 --> q5 : a
          q5 --> q5 : a
          q0 --> [*]
          q1 --> [*]
          q2 --> [*]
          q4 --> [*]
          q5 --> [*]
          
          note right of q0 : Now accepting
          note right of q1 : Now accepting
          note right of q2 : Accept State
          note right of q4 : Now accepting
          note right of q5 : Accept State
      `,
      eliminationProcess: `
        graph TD
          A["Complex ε-closures"] --> B["ε-closure(q0) = {q0,q1,q3,q4,q5}"]
          B --> C["ε-closure(q1) = {q1,q4,q5}"]
          C --> D["ε-closure(q4) = {q4,q5}"]
          D --> E["Compute new transitions"]
          E --> F["Add all reachable paths"]
          F --> G["Update accept states"]
          G --> H["Remove ε-transitions"]
          
          style A fill:#ffebee
          style H fill:#c8e6c9
      `,
      enfa: {
        states: ["q0", "q1", "q2", "q3", "q4", "q5"],
        alphabet: ["a", "b"],
        transitions: {
          q0: { a: [], b: [], ε: ["q1", "q3"] },
          q1: { a: ["q2"], b: [], ε: ["q4"] },
          q2: { a: [], b: ["q5"], ε: [] },
          q3: { a: [], b: ["q4"], ε: [] },
          q4: { a: [], b: [], ε: ["q5"] },
          q5: { a: ["q5"], b: [], ε: [] },
        },
        startState: "q0",
        acceptStates: ["q2", "q5"],
      },
    },
  ]

  const question = questions[questionIndex]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <CardTitle className="text-xl">
              Question {questionIndex + 1}: {question.title}
            </CardTitle>
            <Badge
              variant={
                question.difficulty === "Easy"
                  ? "secondary"
                  : question.difficulty === "Medium"
                    ? "default"
                    : "destructive"
              }
            >
              {question.difficulty}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold mb-2">Problem Statement:</h3>
            <p>{question.problem}</p>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Given ε-NFA:</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p>
                <strong>States (Q):</strong> {`{${question.enfa.states.join(", ")}}`}
              </p>
              <p>
                <strong>Alphabet (Σ):</strong> {`{${question.enfa.alphabet.join(", ")}}`}
              </p>
              <p>
                <strong>Start State (q₀):</strong> {question.enfa.startState}
              </p>
              <p>
                <strong>Accept States (F):</strong> {`{${question.enfa.acceptStates.join(", ")}}`}
              </p>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-2">ε-NFA State Diagram:</h3>
            <MermaidDiagram chart={question.enfaDiagram} id={`enfa-nfa-${questionIndex}`} />
          </div>

          <div>
            <h3 className="font-semibold mb-2">Transition Table:</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full border border-gray-300">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border border-gray-300 px-4 py-2">State</th>
                    {question.enfa.alphabet.map((symbol) => (
                      <th key={symbol} className="border border-gray-300 px-4 py-2">
                        {symbol}
                      </th>
                    ))}
                    <th className="border border-gray-300 px-4 py-2">ε</th>
                  </tr>
                </thead>
                <tbody>
                  {question.enfa.states.map((state) => (
                    <tr key={state}>
                      <td className="border border-gray-300 px-4 py-2 font-mono">
                        {state}
                        {question.enfa.acceptStates.includes(state) ? "*" : ""}
                      </td>
                      {question.enfa.alphabet.map((symbol) => (
                        <td key={symbol} className="border border-gray-300 px-4 py-2 font-mono">
                          {`{${question.enfa.transitions[state][symbol].join(", ") || "∅"}}`}
                        </td>
                      ))}
                      <td className="border border-gray-300 px-4 py-2 font-mono">
                        {`{${question.enfa.transitions[state]["ε"].join(", ") || "∅"}}`}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </CardContent>
      </Card>

      {showSolution && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800">Solution: ε-NFA to NFA Conversion</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-semibold mb-2 text-green-800">Elimination Process:</h3>
              <MermaidDiagram chart={question.eliminationProcess} id={`elimination-${questionIndex}`} />
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Resulting NFA:</h3>
              <MermaidDiagram chart={question.nfaDiagram} id={`nfa-result-${questionIndex}`} />
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Conversion Algorithm:</h3>
              <div className="space-y-3">
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 1: Compute ε-closures</h4>
                  <p>For each state q, compute ε-closure(q) = all states reachable from q via ε-transitions only</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 2: Modify Transition Function</h4>
                  <p>For each state q and symbol a: δ'(q,a) = ε-closure(⋃{`{δ(p,a) | p ∈ ε-closure(q)}`})</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 3: Update Accept States</h4>
                  <p>State q is accepting in NFA if ε-closure(q) contains any original accept state</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 4: Remove ε-transitions</h4>
                  <p>The resulting NFA has no ε-transitions and accepts the same language</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Mathematical Formulation:</h3>
              <div className="bg-white p-4 rounded-lg border border-green-200 font-mono text-sm">
                <p>Given ε-NFA M = (Q, Σ, δ, q₀, F)</p>
                <p>Construct NFA M' = (Q, Σ, δ', q₀, F') where:</p>
                <p className="mt-2">δ'(q, a) = ε-closure(⋃{`{δ(p, a) | p ∈ ε-closure(q)}`})</p>
                <p>F' = {`{q ∈ Q | ε-closure(q) ∩ F ≠ ∅}`}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function CFGToPDAQuestions({ questionIndex, showSolution }: { questionIndex: number; showSolution: boolean }) {
  const questions = [
    {
      difficulty: "Easy",
      title: "Basic CFG to PDA Conversion",
      problem: "Convert the following Context-Free Grammar to Pushdown Automaton:",
      cfgDiagram: `
        graph TD
          A["S → aSb"] --> B["Generates: a^n b^n"]
          C["S → ε"] --> B
          B --> D["Language: {a^n b^n | n ≥ 0}"]
          
          style A fill:#e1f5fe
          style C fill:#e1f5fe
          style D fill:#c8e6c9
      `,
      pdaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : ε,Z0/SZ0
          q1 --> q1 : ε,S/aSb
          q1 --> q1 : ε,S/ε
          q1 --> q1 : a,a/ε
          q1 --> q1 : b,b/ε
          q1 --> q2 : ε,Z0/Z0
          q2 --> [*]
          
          note right of q0 : Start
          note right of q1 : Process
          note right of q2 : Accept
      `,
      conversionProcess: `
        graph TD
          A["CFG: S → aSb | ε"] --> B["Create PDA states: q0, q1, q2"]
          B --> C["Initialize: (q0,ε,Z0) → (q1,SZ0)"]
          C --> D["Add productions: (q1,ε,S) → (q1,aSb)"]
          D --> E["Add productions: (q1,ε,S) → (q1,ε)"]
          E --> F["Match terminals: (q1,a,a) → (q1,ε)"]
          F --> G["Match terminals: (q1,b,b) → (q1,ε)"]
          G --> H["Accept: (q1,ε,Z0) → (q2,Z0)"]
          
          style A fill:#ffebee
          style H fill:#c8e6c9
      `,
      cfg: {
        variables: ["S"],
        terminals: ["a", "b"],
        productions: ["S → aSb", "S → ε"],
        startSymbol: "S",
      },
      language: "L = {aⁿbⁿ | n ≥ 0}",
    },
    {
      difficulty: "Easy-Medium",
      title: "CFG with Multiple Productions",
      problem: "Convert CFG with multiple production rules to PDA:",
      cfgDiagram: `
        graph TD
          A["S → aAc"] --> B["A → aAb"]
          B --> C["A → ε"]
          C --> D["Language: {a^(n+1) b^n c | n ≥ 0}"]
          
          style A fill:#e1f5fe
          style B fill:#fff3e0
          style C fill:#fff3e0
          style D fill:#c8e6c9
      `,
      pdaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : ε,Z0/SZ0
          q1 --> q1 : ε,S/aAc
          q1 --> q1 : ε,A/aAb
          q1 --> q1 : ε,A/ε
          q1 --> q1 : a,a/ε
          q1 --> q1 : b,b/ε
          q1 --> q1 : c,c/ε
          q1 --> q2 : ε,Z0/Z0
          q2 --> [*]
          
          note right of q0 : Start
          note right of q1 : Process
          note right of q2 : Accept
      `,
      conversionProcess: `
        graph TD
          A["Multiple Variables: S, A"] --> B["Create production rules"]
          B --> C["S → aAc: (q1,ε,S) → (q1,aAc)"]
          C --> D["A → aAb: (q1,ε,A) → (q1,aAb)"]
          D --> E["A → ε: (q1,ε,A) → (q1,ε)"]
          E --> F["Terminal matching for a,b,c"]
          F --> G["Stack-based parsing"]
          
          style A fill:#ffebee
          style G fill:#c8e6c9
      `,
      cfg: {
        variables: ["S", "A"],
        terminals: ["a", "b", "c"],
        productions: ["S → aAc", "A → aAb", "A → ε"],
        startSymbol: "S",
      },
      language: "L = {aⁿ⁺¹bⁿc | n ≥ 0}",
    },
    {
      difficulty: "Medium",
      title: "CFG with Left and Right Recursion",
      problem: "Convert CFG with both left and right recursive productions:",
      cfgDiagram: `
        graph TD
          A["S → AB"] --> B["A → aA | a"]
          B --> C["B → bB | b"]
          C --> D["Language: {a^i b^j | i ≥ 1, j ≥ 1}"]
          
          style A fill:#e1f5fe
          style B fill:#fff3e0
          style C fill:#f3e5f5
          style D fill:#c8e6c9
      `,
      pdaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : ε,Z0/SZ0
          q1 --> q1 : ε,S/AB
          q1 --> q1 : ε,A/aA
          q1 --> q1 : ε,A/a
          q1 --> q1 : ε,B/bB
          q1 --> q1 : ε,B/b
          q1 --> q1 : a,a/ε
          q1 --> q1 : b,b/ε
          q1 --> q2 : ε,Z0/Z0
          q2 --> [*]
          
          note right of q0 : Start
          note right of q1 : Process
          note right of q2 : Accept
      `,
      conversionProcess: `
        graph TD
          A["Recursive Productions"] --> B["Right recursion: A → aA"]
          B --> C["Base case: A → a"]
          C --> D["Right recursion: B → bB"]
          D --> E["Base case: B → b"]
          E --> F["Concatenation: S → AB"]
          F --> G["PDA handles recursion via stack"]
          
          style A fill:#ffebee
          style G fill:#c8e6c9
      `,
      cfg: {
        variables: ["S", "A", "B"],
        terminals: ["a", "b"],
        productions: ["S → AB", "A → aA", "A → a", "B → bB", "B → b"],
        startSymbol: "S",
      },
      language: "L = {aⁱbʲ | i ≥ 1, j ≥ 1}",
    },
    {
      difficulty: "Medium-Hard",
      title: "Ambiguous CFG to PDA",
      problem: "Convert ambiguous CFG with multiple derivation paths:",
      cfgDiagram: `
        graph TD
          A["S → AB | BA"] --> B["A → aAa | c"]
          A --> C["B → bBb | c"]
          B --> D["Palindromic structures"]
          C --> D
          D --> E["Language: Palindromes with c centers"]
          
          style A fill:#e1f5fe
          style B fill:#fff3e0
          style C fill:#f3e5f5
          style D fill:#e8f5e8
          style E fill:#c8e6c9
      `,
      pdaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : ε,Z0/SZ0
          q1 --> q1 : ε,S/AB
          q1 --> q1 : ε,S/BA
          q1 --> q1 : ε,A/aAa
          q1 --> q1 : ε,A/c
          q1 --> q1 : ε,B/bBb
          q1 --> q1 : ε,B/c
          q1 --> q1 : a,a/ε
          q1 --> q1 : b,b/ε
          q1 --> q1 : c,c/ε
          q1 --> q2 : ε,Z0/Z0
          q2 --> [*]
          
          note right of q0 : Start
          note right of q1 : Process (Non-deterministic)
          note right of q2 : Accept
      `,
      conversionProcess: `
        graph TD
          A["Ambiguous Grammar"] --> B["Multiple derivations possible"]
          B --> C["S → AB or S → BA"]
          C --> D["Non-deterministic PDA"]
          D --> E["Stack tracks all possibilities"]
          E --> F["Palindromic pattern recognition"]
          F --> G["Accept on successful parse"]
          
          style A fill:#ffebee
          style D fill:#fff3e0
          style G fill:#c8e6c9
      `,
      cfg: {
        variables: ["S", "A", "B"],
        terminals: ["a", "b", "c"],
        productions: ["S → AB | BA", "A → aAa | c", "B → bBb | c"],
        startSymbol: "S",
      },
      language: "L = {strings with palindromic a's and b's around c's}",
    },
    {
      difficulty: "Hard",
      title: "Complex CFG with Nested Structures",
      problem: "Convert complex CFG with nested and recursive structures:",
      cfgDiagram: `
        graph TD
          A["S → ASB | C"] --> B["A → aAa | a"]
          A --> C["B → bBb | b"]
          A --> D["C → cCd | cd"]
          B --> E["Nested palindromes"]
          C --> E
          D --> F["Balanced parentheses-like"]
          E --> G["Complex nested language"]
          F --> G
          
          style A fill:#e1f5fe
          style B fill:#fff3e0
          style C fill:#f3e5f5
          style D fill:#e8f5e8
          style G fill:#c8e6c9
      `,
      pdaDiagram: `
        stateDiagram-v2
          [*] --> q0
          q0 --> q1 : ε,Z0/SZ0
          q1 --> q1 : ε,S/ASB
          q1 --> q1 : ε,S/C
          q1 --> q1 : ε,A/aAa
          q1 --> q1 : ε,A/a
          q1 --> q1 : ε,B/bBb
          q1 --> q1 : ε,B/b
          q1 --> q1 : ε,C/cCd
          q1 --> q1 : ε,C/cd
          q1 --> q1 : a,a/ε
          q1 --> q1 : b,b/ε
          q1 --> q1 : c,c/ε
          q1 --> q1 : d,d/ε
          q1 --> q2 : ε,Z0/Z0
          q2 --> [*]
          
          note right of q0 : Start
          note right of q1 : Process (Complex)
          note right of q2 : Accept
      `,
      conversionProcess: `
        graph TD
          A["Complex Nested Grammar"] --> B["Multiple recursive patterns"]
          B --> C["S → ASB: Nested structure"]
          C --> D["A → aAa: Palindromic a's"]
          D --> E["B → bBb: Palindromic b's"]
          E --> F["C → cCd: Balanced c,d"]
          F --> G["PDA manages complex stack"]
          G --> H["Non-deterministic parsing"]
          
          style A fill:#ffebee
          style H fill:#c8e6c9
      `,
      cfg: {
        variables: ["S", "A", "B", "C"],
        terminals: ["a", "b", "c", "d"],
        productions: ["S → ASB | C", "A → aAa | a", "B → bBb | b", "C → cCd | cd"],
        startSymbol: "S",
      },
      language: "L = {aⁱaⁱbʲbʲ | i,j ≥ 1} ∪ {cⁿdⁿ | n ≥ 1}",
    },
  ]

  const question = questions[questionIndex]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <CardTitle className="text-xl">
              Question {questionIndex + 1}: {question.title}
            </CardTitle>
            <Badge
              variant={
                question.difficulty === "Easy"
                  ? "secondary"
                  : question.difficulty === "Medium"
                    ? "default"
                    : "destructive"
              }
            >
              {question.difficulty}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold mb-2">Problem Statement:</h3>
            <p>{question.problem}</p>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Given Context-Free Grammar:</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p>
                <strong>Variables (V):</strong> {`{${question.cfg.variables.join(", ")}}`}
              </p>
              <p>
                <strong>Terminals (T):</strong> {`{${question.cfg.terminals.join(", ")}}`}
              </p>
              <p>
                <strong>Start Symbol:</strong> {question.cfg.startSymbol}
              </p>
              <p>
                <strong>Productions (P):</strong>
              </p>
              <ul className="ml-4 mt-2">
                {question.cfg.productions.map((prod, idx) => (
                  <li key={idx} className="font-mono">
                    {prod}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Grammar Structure:</h3>
            <MermaidDiagram chart={question.cfgDiagram} id={`cfg-${questionIndex}`} />
          </div>

          <div>
            <h3 className="font-semibold mb-2">Language Generated:</h3>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <p className="font-mono">{question.language}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {showSolution && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800">Solution: CFG to PDA Conversion</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-semibold mb-2 text-green-800">Conversion Process:</h3>
              <MermaidDiagram chart={question.conversionProcess} id={`cfg-conversion-${questionIndex}`} />
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Resulting PDA:</h3>
              <MermaidDiagram chart={question.pdaDiagram} id={`pda-${questionIndex}`} />
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">PDA Construction Algorithm:</h3>
              <div className="space-y-3">
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 1: Create PDA States</h4>
                  <p>Create three states: q₀ (start), q₁ (main processing), q₂ (accept)</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 2: Initialize Stack</h4>
                  <p>Push start symbol onto stack: (q₀, ε, Z₀) → (q₁, SZ₀)</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 3: Add Production Rules</h4>
                  <p>For each production A → α, add: (q₁, ε, A) → (q₁, α)</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 4: Add Terminal Matching</h4>
                  <p>For each terminal a, add: (q₁, a, a) → (q₁, ε)</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium mb-2">Step 5: Accept Condition</h4>
                  <p>Accept when stack contains only Z₀: (q₁, ε, Z₀) → (q₂, Z₀)</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Formal PDA Definition:</h3>
              <div className="bg-white p-4 rounded-lg border border-green-200 font-mono text-sm">
                <p>M = (Q, Σ, Γ, δ, q₀, Z₀, F)</p>
                <p className="mt-2">Where:</p>
                <p>Q = {`{q₀, q₁, q₂}`} (finite set of states)</p>
                <p>Σ = {`{${question.cfg.terminals.join(", ")}}`} (input alphabet)</p>
                <p>
                  Γ = {`{Z₀, ${question.cfg.variables.join(", ")}, ${question.cfg.terminals.join(", ")}}`} (stack
                  alphabet)
                </p>
                <p>q₀ = q₀ (start state)</p>
                <p>Z₀ = Z₀ (initial stack symbol)</p>
                <p>F = {`{q₂}`} (accept states)</p>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Example Derivation:</h3>
              <div className="bg-white p-4 rounded-lg border border-green-200">
                <h4 className="font-medium mb-2">Trace for sample string:</h4>
                <div className="font-mono text-sm space-y-1">
                  <p>Configuration: (state, remaining_input, stack)</p>
                  <p>Initial: (q₀, input_string, Z₀)</p>
                  <p>Step 1: (q₁, input_string, SZ₀)</p>
                  <p>Step 2: Apply production rules...</p>
                  <p>Step 3: Match terminals...</p>
                  <p>Final: (q₂, ε, Z₀) ← Accept</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-green-800">Key Properties:</h3>
              <div className="space-y-2">
                <div className="bg-white p-3 rounded border border-green-200">
                  <p>
                    <strong>Deterministic:</strong> The PDA is non-deterministic due to ε-transitions and production
                    choices
                  </p>
                </div>
                <div className="bg-white p-3 rounded border border-green-200">
                  <p>
                    <strong>Acceptance:</strong> By empty stack and final state
                  </p>
                </div>
                <div className="bg-white p-3 rounded border border-green-200">
                  <p>
                    <strong>Language Class:</strong> Context-Free Language (CFL)
                  </p>
                </div>
                <div className="bg-white p-3 rounded border border-green-200">
                  <p>
                    <strong>Equivalence:</strong> L(CFG) = L(PDA) - both recognize the same language
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
